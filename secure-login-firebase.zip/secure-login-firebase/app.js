// Firebase SDK import (pakai CDN modular v9)
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js";
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/9.22.2/firebase-auth.js";

// 🔧 Ganti dengan config kamu dari Firebase Console
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// 🔐 DOM Elements
const email = document.getElementById("email");
const password = document.getElementById("password");
const registerBtn = document.getElementById("register-btn");
const loginBtn = document.getElementById("login-btn");
const logoutBtn = document.getElementById("logout-btn");
const statusText = document.getElementById("status");

// 🧾 Register User
registerBtn.addEventListener("click", async () => {
  try {
    await createUserWithEmailAndPassword(auth, email.value, password.value);
    statusText.textContent = "✅ Registrasi berhasil!";
  } catch (error) {
    statusText.textContent = "⚠️ " + error.message;
  }
});

// 🔑 Login User
loginBtn.addEventListener("click", async () => {
  try {
    await signInWithEmailAndPassword(auth, email.value, password.value);
    statusText.textContent = "✅ Login berhasil!";
  } catch (error) {
    statusText.textContent = "⚠️ " + error.message;
  }
});

// 🚪 Logout User
logoutBtn.addEventListener("click", async () => {
  await signOut(auth);
  statusText.textContent = "👋 Logout berhasil.";
});

// 👁️‍🗨️ Cek status login
onAuthStateChanged(auth, (user) => {
  if (user) {
    statusText.textContent = `👋 Halo, ${user.email}`;
    logoutBtn.classList.remove("hidden");
    loginBtn.classList.add("hidden");
    registerBtn.classList.add("hidden");
  } else {
    statusText.textContent = "Silakan login atau daftar.";
    logoutBtn.classList.add("hidden");
    loginBtn.classList.remove("hidden");
    registerBtn.classList.remove("hidden");
  }
});
