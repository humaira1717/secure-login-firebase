// Global Toast
function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    document.body.appendChild(toast);
    toast.style.display = 'block';
    setTimeout(() => { toast.remove(); }, 3000);
}

// Dark / Light Mode Toggle
const toggleMode = () => document.body.classList.toggle('dark-mode');
