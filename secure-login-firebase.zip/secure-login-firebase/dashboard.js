import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js";
import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyCSBTEoaqv-8utu3I7HnNaQCECJQOsTONM",
  authDomain: "login-firebase-7bb1c.firebaseapp.com",
  projectId: "login-firebase-7bb1c",
  storageBucket: "login-firebase-7bb1c.firebasestorage.app",
  messagingSenderId: "700845122855",
  appId: "1:700845122855:web:cbd357e452d20dfe80f502",
  measurementId: "G-ZNWJ4P115E"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

const info = document.getElementById("user-info");
const logout = document.getElementById("logout-btn");

// 🔐 Cek status login user
onAuthStateChanged(auth, (user) => {
  if (user) {
    const waktu = new Date().toLocaleTimeString();
    info.innerHTML = `
      👤 <b>${user.email}</b><br>
      ⏰ Login pada: ${waktu}<br>
      ☁️ Akses aman melalui Firebase Cloud Authentication
    `;
  } else {
    // Jika user belum login, arahkan kembali
    window.location.href = "login.html";
  }
});

// 🚪 Logout handler
logout.addEventListener("click", async () => {
  await signOut(auth);
  alert("Anda telah logout dari sistem 🔒");
  window.location.href = "login.html";
});
