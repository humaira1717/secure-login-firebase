import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyCSBTEoaqv-8utu3I7HnNaQCECJQOsTONM",
  authDomain: "login-firebase-7bb1c.firebaseapp.com",
  projectId: "login-firebase-7bb1c",
  storageBucket: "login-firebase-7bb1c.firebasestorage.app",
  messagingSenderId: "700845122855",
  appId: "1:700845122855:web:cbd357e452d20dfe80f502",
  measurementId: "G-ZNWJ4P115E"
};

// 🔥 Inisialisasi Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

const email = document.getElementById("email");
const password = document.getElementById("password");
const btn = document.getElementById("register-btn");
const status = document.getElementById("status");

btn.addEventListener("click", async () => {
  try {
    const userCred = await createUserWithEmailAndPassword(auth, email.value, password.value);
    status.textContent = `✅ Registrasi berhasil: ${userCred.user.email}`;
    status.style.color = "lime";
    setTimeout(() => (window.location = "login.html"), 2000);
  } catch (err) {
    status.textContent = "⚠️ " + err.message;
    status.style.color = "yellow";
  }
});
