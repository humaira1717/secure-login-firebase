import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js";
import { getAuth, signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyCSBTEoaqv-8utu3I7HnNaQCECJQOsTONM",
  authDomain: "login-firebase-7bb1c.firebaseapp.com",
  projectId: "login-firebase-7bb1c",
  storageBucket: "login-firebase-7bb1c.firebasestorage.app",
  messagingSenderId: "700845122855",
  appId: "1:700845122855:web:cbd357e452d20dfe80f502",
  measurementId: "G-ZNWJ4P115E"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");
const loginBtn = document.getElementById("login-btn");
const statusText = document.getElementById("status");

loginBtn.addEventListener("click", async () => {
  const email = emailInput.value.trim();
  const password = passwordInput.value.trim();

  if (!email || !password) {
    statusText.textContent = "⚠️ Harap isi email dan password.";
    statusText.style.color = "yellow";
    return;
  }

  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;

    statusText.textContent = `✅ Login berhasil sebagai ${user.email}`;
    statusText.style.color = "lime";
    console.log("Login sukses:", user.email);

    // Redirect ke dashboard setelah 1 detik
    setTimeout(() => {
      window.location.href = "dashboard.html";
    }, 1000);

  } catch (error) {
    console.error("Login error:", error.message);
    statusText.textContent = "⚠️ " + error.message;
    statusText.style.color = "orange";
  }
});
